﻿using BarRating.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using System.Collections.Generic;

namespace BarRating.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
              : base(options)
        {
        }

        public DbSet<User> Users { get; set; }
    
    public DbSet <Bar> Bars {  get; set; }

    public DbSet<Review> Reviews {  get; set; }
    }
}