﻿namespace BarRating.Data
{
    public class Base
    {
    }
}